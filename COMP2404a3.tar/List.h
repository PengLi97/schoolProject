#ifndef LIST_H
#define LIST_H
#include <string>
#include "Event.h"

using namespace std;

class List
{
   class Node
    {
        friend class List;
        private:
        Event* event;
        Node* next;
        Node* prev;
    };
 
    public:
        List();
        ~List();
        void add(Event*); 
        void format(string& outStr);
    private:
        Node* head;
};

#endif
