#ifndef WORKEVENT_H
#define WORKEVENT_H

#include "Event.h"
#include <string>
using namespace std;

class WorkEvent : public Event
{
    public:
        WorkEvent(string n, int prio);
        bool lessThan(Event*);
};

#endif

