#include <iostream>
#include <iomanip>
using namespace std;

//Interact with user and control all data input and output

#include "View.h"
#include "Calendar.h"

//Ask user to input selection
bool View::Display()
{
    int numOptions = 1;
    int selection = -1;

    cout << endl;
    cout << "(1) Add event" << endl;
    cout << "(0) Exit" << endl;

    while (selection < 0 || selection > numOptions) {
        cout << "Enter your selection: \n";
        cin >> selection;
    }
    if (selection == 1){
        return true;
    }
    else {
        return false;
    }
    
}
bool View::readEventType(){
    string type = "";
    cout << "What is the type of event? (school or work) ";
    cin  >> type;
    if (type == "school") {return true;}
    else if(type == "work"){return false;}
    return readEventType();
}


//read user input and make change to the reference
void View::Reading(int& d, int& m, int& y, string& E, int& h, int& min, int& prio)
{
      cout << "day:   ";
      cin  >> d;
      cout << "month: ";
      cin  >> m;
      cout << "year:  ";
      cin  >> y;
      cout << "Event name:  ";
      cin  >> E;
      cout << "hour:    ";
      cin  >> h;
      cout << "minute   ";
      cin  >> min;
      cout << "priority number:   ";
      cin >> prio;
}

void View::PrintCalendar(string& outStr)
{
    cout<<outStr<<endl;
}
