#ifndef CALENDAR_H
#define CALENDAR_H

#include "Event.h"
#include "List.h"

#define size 128

class Calendar
{
    public:
      Calendar(string="");
      ~Calendar();
      void add(Event*);
      void format(string&);
    private:
      string name;
      List list;

};








#endif
