#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;

//Data object illustrate day, month, year and time of Event

#include "Date.h"
#include "Time.h"

Date::Date(int d, int m, int y, int h, int min)
{
  set(d, m, y, h, min);
}

//comparing date
bool Date::lessThan(Date* d)
{
    if (d->year  > year) return true;
    else if(d->year == year && d->month > month) return true;
    else if(d->year == year && d->month == month && d->day > day) return true;
    else if(d->year == year && d->month == month && 
            d->day == day && d->time.lessThan(time)) return true;
    else return false;    
}

void Date::set(int d,int m,int y, int h, int min)
{
  year  = ( ( y > 0) ? y : 0 );
  month = ( ( m > 0 && m <= 12) ? m : 0 );
  day   = ( ( d > 0 && d <= lastDayInMonth() ) ? d : 0 );
  time.set(h,min,0);
}

//add date data to outStr
void Date::format(string& outStr)
{
    stringstream ss;
    ss<<getMonthStr()<<" "<<day<<", "<<year<<","<<endl;
    outStr += ss.str();
    time.format(outStr);
}


int Date::lastDayInMonth()
{
  switch(month)
  {
    case 2:
      if (leapYear())
        return 29;
      else
        return 28;
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
      return 31;
    default:
      return 30;
  }
}

bool Date::leapYear()
{
  if ( year%400 == 0 ||
       (year%4 == 0 && year%100 != 0) )
    return true;
  else
    return false;
}

//return Month string depend on number
string Date::getMonthStr() 
{
  string monthStrings[] = { 
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December" };

  if ( month >= 1 && month <= 12 )
    return monthStrings[month-1];
  else
    return "Unknown";
}

