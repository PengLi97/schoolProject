#include <string>
#include "View.h"
#include "Calendar.h"

using namespace std;

class Control
{
    public:
        void launch();
    private:
        Calendar school;
        Calendar work;
        View view;
        
};

