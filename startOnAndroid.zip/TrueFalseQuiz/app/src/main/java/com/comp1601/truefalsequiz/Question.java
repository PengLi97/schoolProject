package com.comp1601.truefalsequiz;

/**
 * Created by ldnel on 2017-12-31.
 */


public class Question {
    private String mQuestion;
    private String mAnswer = "not anwser yet";

    public Question(String aQuestionAnswerString) { mQuestion = aQuestionAnswerString; }

    public String getQuestion(){ return mQuestion; }
    public void setAnsmer(String ans){ mAnswer = ans; }
    public String getAnswer(){ return mAnswer; }

}
