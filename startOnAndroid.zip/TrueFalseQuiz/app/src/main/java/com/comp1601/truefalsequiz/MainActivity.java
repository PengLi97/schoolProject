package com.comp1601.truefalsequiz;

import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button A_Button;
    private Button B_Button;
    private Button C_Button;
    private Button D_Button;
    private Button E_Button;
    private Button prev_Button;
    private Button submit_Button;
    private Button next_Button;
    private Button restart_Button;
    private final String[] answer = {"A","A","A","A","A","A","A","A","A","A"};
    private boolean sub = true;// if submit(false) submit button would disable, unless restart
    private boolean choose = true;//disable
    private TextView mQuestionTextView;
    private TextView mChoice_TextView;
    private ArrayList<Question> mQuestions = new ArrayList<>();
    private ArrayList<Question> mChoice = new ArrayList<>();
    private ArrayList<String> user = new ArrayList<>();
    private int mCurrentQuestionIndex = -1;
    //private final String TAG = "1601QuizMainActivity";
    private  final String TAG = this.getClass().getSimpleName() + " @" + System.identityHashCode(this);
    private String getDeviceInfo(){
        String s = "Device info:";
        try {

            s += "\n OS Version: "          + System.getProperty("OS Version")+
                    "(" + Build.VERSION.INCREMENTAL + ")";
            s += "\n OS API Level: "        + Build.VERSION.SDK_INT;
            s += "\n Device: "              + Build.DEVICE;
            s += "\n Model (and Product): " + Build.MODEL   +
                    " (" + Build.PRODUCT + ")";
            s += "\n RELEASE: "             + Build.VERSION.RELEASE;
            s += "\n BRAND: "               + Build.BRAND;
            s += "\n DISPLAY: "             + Build.DISPLAY;
            s += "\n HARWARE: "             + Build.HARDWARE;
            s += "\n Build ID: "            + Build.ID;
            s += "\n MANUFACTURER: "        + Build.MANUFACTURER;
            s += "\n User: "                + Build.USER;
            s += "\n HOST: "                + Build.HOST;
        } catch (Exception e) {
            Log.e(TAG, "Error getting Device INFo");
        }
        return s;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        A_Button = (Button) findViewById(R.id.A_button);
        B_Button = (Button) findViewById(R.id.B_button);
        C_Button = (Button) findViewById(R.id.C_button);
        D_Button = (Button) findViewById(R.id.D_button);
        E_Button = (Button) findViewById(R.id.E_button);
        prev_Button = (Button) findViewById(R.id.prev_button);
        submit_Button = (Button) findViewById(R.id.submit_button);
        next_Button = (Button) findViewById(R.id.next_button);
        restart_Button = (Button) findViewById(R.id.restart_button);

        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);
        mChoice_TextView = (TextView) findViewById(R.id.choice_text_view);
        //adding question
        mQuestions.add(new Question(getString(R.string.question_1)));
        mQuestions.add(new Question(getString(R.string.question_2)));
        mQuestions.add(new Question(getString(R.string.question_3)));
        mQuestions.add(new Question(getString(R.string.question_4)));
        mQuestions.add(new Question(getString(R.string.question_5)));
        mQuestions.add(new Question(getString(R.string.question_6)));
        mQuestions.add(new Question(getString(R.string.question_7)));
        mQuestions.add(new Question(getString(R.string.question_8)));
        mQuestions.add(new Question(getString(R.string.question_9)));
        mQuestions.add(new Question(getString(R.string.question_10)));

        //adding choices
        mChoice.add(new Question(getString(R.string.question_1_choice)));
        mChoice.add(new Question(getString(R.string.question_2_choice)));
        mChoice.add(new Question(getString(R.string.question_3_choice)));
        mChoice.add(new Question(getString(R.string.question_4_choice)));
        mChoice.add(new Question(getString(R.string.question_5_choice)));
        mChoice.add(new Question(getString(R.string.question_6_choice)));
        mChoice.add(new Question(getString(R.string.question_7_choice)));
        mChoice.add(new Question(getString(R.string.question_8_choice)));
        mChoice.add(new Question(getString(R.string.question_9_choice)));
        mChoice.add(new Question(getString(R.string.question_10_choice)));

        for(int i = 0; i < answer.length; i++)
            user.add("0");
        // the action on submit button
        submit_Button.setOnClickListener(v -> {
            choose = false;
            A_Button.setBackgroundColor(Color.TRANSPARENT);
            B_Button.setBackgroundColor(Color.TRANSPARENT);
            C_Button.setBackgroundColor(Color.TRANSPARENT);
            D_Button.setBackgroundColor(Color.TRANSPARENT);
            E_Button.setBackgroundColor(Color.TRANSPARENT);
            if(!sub) return;
            Log.i(TAG, "submit Button Pressed");
            int correct = 0; //count for correct answer
            //for loop to check the correct answer
            for(int i = 0; i < user.size(); i++){
                if(user.get(i) == answer[i])   correct++;
            }
            //display result
            mQuestionTextView.setText("YOU GRADE");
            mChoice_TextView.setText(correct + "/10");
            sub = false;
        });
        // the action for next button
        next_Button.setOnClickListener(v -> {

            if(!sub)return;
            // every time click next should display the color on each chioce
            A_Button.setBackgroundColor(Color.TRANSPARENT);
            B_Button.setBackgroundColor(Color.TRANSPARENT);
            C_Button.setBackgroundColor(Color.TRANSPARENT);
            D_Button.setBackgroundColor(Color.TRANSPARENT);
            E_Button.setBackgroundColor(Color.TRANSPARENT);

            // if size out of bound display it
            if (mCurrentQuestionIndex >= mQuestions.size()-1) {
                mQuestionTextView.setText("END");
                mChoice_TextView.setText("click sumbit button to check the result");
                choose = false;
            }
            else {
                //adjust the user choose answer or not;
                if (mCurrentQuestionIndex >= 0) {
                        //user can check their previous answer;
                        switch (user.get(mCurrentQuestionIndex+1)) {
                            case "A":
                                A_Button.setBackgroundColor(Color.GREEN);
                                break;
                            case "B":
                                B_Button.setBackgroundColor(Color.GREEN);
                                break;
                            case "C":
                                C_Button.setBackgroundColor(Color.GREEN);
                                break;
                            case "D":
                                D_Button.setBackgroundColor(Color.GREEN);
                                break;
                            case "E":
                                E_Button.setBackgroundColor(Color.GREEN);
                                break;
                            default:
                                break;
                        }
                }
                mCurrentQuestionIndex++;  // increase index
                // go to the next question
                mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());
                mChoice_TextView.setText(mChoice.get(mCurrentQuestionIndex).getQuestion());

            }
        });
        A_Button.setOnClickListener(v -> {
            //Handle the yes button click
            //System.out.println("Yes Button Clicked");
            if(!choose) return;
            Log.i(TAG, "A Button Pressed");
            //if it is not question page, button do not response
            if(mCurrentQuestionIndex == -1) return;
            A_Button.setBackgroundColor(Color.GREEN);
            B_Button.setBackgroundColor(Color.TRANSPARENT);
            C_Button.setBackgroundColor(Color.TRANSPARENT);
            D_Button.setBackgroundColor(Color.TRANSPARENT);
            E_Button.setBackgroundColor(Color.TRANSPARENT);
            //add user choose into the user answer array if user list donot have element
            //if user list have element change it
            if(user.size()-1 > mCurrentQuestionIndex)
                user.set(mCurrentQuestionIndex,"A");
            else
                user.set(mCurrentQuestionIndex, "A");
            mQuestions.get(mCurrentQuestionIndex).setAnsmer("A");

        });
        B_Button.setOnClickListener(v -> {
            //Handle the no button click
            //System.out.println("No Button Clicked");
            if(!choose) return;
            Log.i(TAG, "B Button Clicked");
            //if it is not question page, button do not response
            if(mCurrentQuestionIndex == -1) return;
            A_Button.setBackgroundColor(Color.TRANSPARENT);
            B_Button.setBackgroundColor(Color.GREEN);
            C_Button.setBackgroundColor(Color.TRANSPARENT);
            D_Button.setBackgroundColor(Color.TRANSPARENT);
            E_Button.setBackgroundColor(Color.TRANSPARENT);
            //add user choose into the user answer array if user list donot have element
            //if user list have element change it
            if(user.size()-1 > mCurrentQuestionIndex)
                user.set(mCurrentQuestionIndex,"B");
            else
                user.set(mCurrentQuestionIndex, "B");
            mQuestions.get(mCurrentQuestionIndex).setAnsmer("B");
        });
        C_Button.setOnClickListener(v -> {
            //Handle the yes button click
            //System.out.println("Yes Button Clicked");
            if(!choose) return;
            Log.i(TAG, "C Button Pressed");
            // answer been choose
            //if it is not question page, button do not response
            if(mCurrentQuestionIndex == -1) return;
            A_Button.setBackgroundColor(Color.TRANSPARENT);
            B_Button.setBackgroundColor(Color.TRANSPARENT);
            C_Button.setBackgroundColor(Color.GREEN);
            D_Button.setBackgroundColor(Color.TRANSPARENT);
            E_Button.setBackgroundColor(Color.TRANSPARENT);
            //add user choose into the user answer array if user list donot have element
            //if user list have element change it
            if(user.size()-1 > mCurrentQuestionIndex)
                user.set(mCurrentQuestionIndex,"C");
            else
                user.set(mCurrentQuestionIndex, "C");
            mQuestions.get(mCurrentQuestionIndex).setAnsmer("C");

        });
        D_Button.setOnClickListener(v -> {
            //Handle the yes button click
            //System.out.println("Yes Button Clicked");
            if(!choose) return;
            Log.i(TAG, "D Button Pressed");
            //if it is not question page, button do not response
            if(mCurrentQuestionIndex == -1) return;
            A_Button.setBackgroundColor(Color.TRANSPARENT);
            B_Button.setBackgroundColor(Color.TRANSPARENT);
            C_Button.setBackgroundColor(Color.TRANSPARENT);
            D_Button.setBackgroundColor(Color.GREEN);
            E_Button.setBackgroundColor(Color.TRANSPARENT);
            //add user choose into the user answer array if user list donot have element
            //if user list have element change it
            if(user.size()-1 > mCurrentQuestionIndex)
                user.set(mCurrentQuestionIndex,"D");
            else
                user.set(mCurrentQuestionIndex, "D");
            mQuestions.get(mCurrentQuestionIndex).setAnsmer("D");

        });
        E_Button.setOnClickListener(v -> {
            //Handle the yes button click
            //System.out.println("Yes Button Clicked");
            if(!choose) return;
            Log.i(TAG, "E Button Pressed");
            //if it is not question page, button do not response
            if(mCurrentQuestionIndex == -1) return;
            // if it is question change the color that user choose
            A_Button.setBackgroundColor(Color.TRANSPARENT);
            B_Button.setBackgroundColor(Color.TRANSPARENT);
            C_Button.setBackgroundColor(Color.TRANSPARENT);
            D_Button.setBackgroundColor(Color.TRANSPARENT);
            E_Button.setBackgroundColor(Color.GREEN);
            //add user choose into the user answer array if user list donot have element
            //if user list have element change it
            if(user.size()-1 > mCurrentQuestionIndex)
                user.set(mCurrentQuestionIndex,"E");
            else
                user.set(mCurrentQuestionIndex, "E");
            mQuestions.get(mCurrentQuestionIndex).setAnsmer("E");

        });
        prev_Button.setOnClickListener(v -> {
            choose = true;
            if(!sub) return;
            //adjust is it the fist page, if it is should do not have any response
            if(mCurrentQuestionIndex == -1 || mCurrentQuestionIndex == 0) return;
            A_Button.setBackgroundColor(Color.TRANSPARENT);
            B_Button.setBackgroundColor(Color.TRANSPARENT);
            C_Button.setBackgroundColor(Color.TRANSPARENT);
            D_Button.setBackgroundColor(Color.TRANSPARENT);
            E_Button.setBackgroundColor(Color.TRANSPARENT);
            // go to previous question, and decrement the index
            mCurrentQuestionIndex--;
            mQuestionTextView.setText(mQuestions.get(mCurrentQuestionIndex).getQuestion());
            mChoice_TextView.setText(mChoice.get(mCurrentQuestionIndex).getQuestion());
            System.out.println(user.get(mCurrentQuestionIndex));
            //user can check their previous answer;
            switch (user.get(mCurrentQuestionIndex)){
                case "A":
                    A_Button.setBackgroundColor(Color.GREEN);
                    break;
                case "B":
                    B_Button.setBackgroundColor(Color.GREEN);
                    break;
                case "C":
                    C_Button.setBackgroundColor(Color.GREEN);
                    break;
                case "D":
                    D_Button.setBackgroundColor(Color.GREEN);
                    break;
                case "E":
                    E_Button.setBackgroundColor(Color.GREEN);
                    break;
                default :
                    break;
            }
        });
        restart_Button.setOnClickListener(v ->{
            //clear array initialize everything
            user.clear();
            for(int i = 0; i < answer.length; i++)
                user.add("0");
            mCurrentQuestionIndex = -1;
            mQuestionTextView.setText("Now you restart the quiz");
            mChoice_TextView.setText("click next");
            sub = true;
            choose = true;

        });

        Log.i(TAG, getDeviceInfo());
    }
  }
