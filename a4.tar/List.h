#ifndef LIST_H
#define LIST_H

#include "Course.h"
using namespace std;
// list become template class now
template <class T>
// the collection class to store courses
class List
{
  template <class V>
  class Node
  {
    friend class List;  // node is List friend allowed list use it member
    friend class CourseList;
    private:
      V* data;     // store data
      Node<V>* next;     // pointer to next one
  };

  public:
    List();             //constucter
    ~List();            //destrctor
    void operator+=(T*);  //adding course to the list
    virtual void print() = 0;       //print the information

  protected:
    Node<T>* head;
    Node<T>* tail;
    Node<T>* temp;
};
template <class T>
List<T>::List()
{
  head = NULL;
  tail = NULL;
}
template <class T>
List<T>::~List()
{
  Node<T> *currNode, *nextNode; // crrent node and next node

  currNode = head;

  while (currNode != NULL) {
    nextNode = currNode->next;
    delete currNode -> data;
    delete currNode;
    currNode = nextNode;
  }
}
// add course to the list
template <class T>
 void List<T>::operator+=(T* course)
{
  Node<T>* tmpNode;      //keep the adding course
  Node<T>* currNode;     //current position
  Node<T>* prevNode;     // previous node

  tmpNode = new Node<T>;
  tmpNode->data = course;
  tmpNode->next = NULL;

  currNode = head;
  prevNode = NULL;
  // if list is not empty
  while (currNode != NULL) {
    if (course->lessThan(currNode->data)) // if couse less than this, break while
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }
  // if list is empty
  if (prevNode == NULL) {
    head = tmpNode;
    tail = tmpNode;
  }
  else {
    prevNode->next = tmpNode;
  }
  tmpNode->next = currNode;
    if(currNode == NULL)
        tail = tmpNode;
    else{
        while(currNode->next != NULL)
            currNode = currNode -> next;
    tail = currNode;
    }
}


#endif
