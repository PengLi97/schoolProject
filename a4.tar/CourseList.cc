#include <iostream>
using namespace std;

#include "CourseList.h"

// initialize the list
CourseList::CourseList(){}

//compute the average of the gpa
float CourseList::computeGPA(){
    float gpa = 0; //keep the gpa
    float n = 0;   //count the total course
    temp = head; // recode state on each stated
    while(temp != NULL){
      gpa += temp->data->getGrade();
      n++;
      temp = temp->next;
    }
    return (gpa/n);
}

//count the course fail or withdraw
int CourseList::computeNumFW(){
  int n= 0;  // count the number of course
  temp = head; // recode state on each stated
  while (temp != NULL){
    if (temp->data->getGrade() == -1 || temp->data->getGrade() == 0)
        n++;
    temp = temp->next;
  }
  return n;
}

// print out the course information
void CourseList::print()
{
  temp = head;
  // loop the list
  while (temp != NULL) {
    temp->data->print();
    temp = temp->next;
  }
  // print the head and tail
  cout <<"--------------" << endl;
  // print the avg and fail/withdraw
  cout << "the courses avg: " << computeGPA() << endl;
  cout << "Fail/withdraw(#): " << computeNumFW() << endl;
  cout << "-----------------------" << endl;



}
