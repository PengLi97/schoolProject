#ifndef STUDENT_H
#define STUDENT_H

#include "defs.h"
#include "Course.h"
#include "CourseList.h"

class Student
{
  public:
    Student(int=0);
    ~Student(); //destrctor construction
    Student& operator+=(Course*); //adding couse to the array
    float computeGPA();  //function that returns the average of all course grades
    int computeNumFW(); // courses that the student has failed or withdraw
    int getId(); // get student id
    void print();

  private:
    int    id;
    CourseList courses; // list keep the courses
};

#endif
