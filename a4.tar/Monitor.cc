#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Monitor.h"

//constructor
Monitor::Monitor(){}
//distructor
Monitor::~Monitor(){}
//prepare for subclass
void Monitor::printLogs(){}
