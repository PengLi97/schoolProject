#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;

#include "Control.h"
#include "GPAMonitor.h"
#include "FWMonitor.h"

Control::Control(){
  Monitor* gpaM = new GPAMonitor(3.0);  // set minimum gpa
  Monitor*  fwM  = new FWMonitor(2);    // set fails > 2
  monitor.push_back(gpaM);              //add GPAMonitor into monitor vector
  monitor.push_back(fwM);               // add FWMonitor into monitor verctor
  vector<string> students;              //declare a STL vector of strings to hold the students
  stringstream ss;
  int id, coursecode, term, grade;
  string prof;

  stuServer.retrieve(students);          //populate the vector with the data from the cloud storage
  // read all student and the course that they take
  for (int i=0; i < students.size(); i++){
    ss.clear();
    ss.str(students[i]);
    ss >> id;
    Student* student = new Student(id);
    while(1){
      ss >> coursecode >> term >> grade >> prof;
      if (coursecode == NULL) break;
      Course* course = new Course(coursecode,grade,term,prof);
      *student+=(course);
    }
    notify(student); // update to cloud to monitor
    storage+=(student);
  }
}
// destrctor for monitor pointer
Control::~Control(){
    for(int i = 0; i < monitor.size() ; i++)
      delete monitor[i];
}
// if there is a new student been added
void Control::notify(Student* newStu){
  for(int i = 0; i < monitor.size() ; i++)
    monitor[i]->update(newStu);

}

void Control::launch()
{
  int courseCode,stuId,grade,term;
  string prof;

  while (view.selection()){
    view.readStuId(stuId); // create dynamic allocater for student
    Student* student = new Student(stuId);
    view.readStuCourse(courseCode,grade,term,prof);
      while(courseCode != 0){
        Course* course = new Course(courseCode,grade,term,prof);// create temp course allocate
        *student+=(course); // add course to the student
        view.readStuCourse(courseCode,grade,term,prof);
      }
    notify(student);
    storage+=(student); // add student to the storage
  }
  view.printStorage(storage);
    cout << "----------------------------storage end------------------"<< endl;
    cout << "--------Student in GPAMonitor" << endl;
    monitor[0]->printLogs();
    cout << "--------Student in FWMonitor" << endl;
    monitor[1]->printLogs();
}
