Peng Li 101047123
Date: 2019 April 4th

purpose:
    Update the assignment 3, add sub class(classlist)to implement encapsulation.
    , read cloud message and upadate to out storage. List class become template
    class, also overload operator += have been implement in this assigment.
    and make sure there is no memory leak in the memory.
source:
Course.cc	Makefile	in.txt    Course.h	    Storage.cc	 Student.cc	  in2.txt
Storage.h	Student.h	defs.h    List.h 		   Control.cc 	Control.h
View.cc	  View.h		main.cc   FWMonitor.cc  FWMonitor.h  GPAMonitor.h Classlist.h
GPAMonitor.cc       Monitor.cc        Monitor.h           Classlist.cc
compile:
  "tar -xvf a4" unzip the file
  "make clean" make sure it is clean
  "make" compile all the class
  "./a4<in.txt" to check for the all output(ignore in2.txt it just a test file)
  "valgrind ./a4<in.txt" to check the memory is leak or not.
