#include <iostream>
#include <iomanip>
using namespace std;
#include "View.h"
View:: View(){
}
// decide wethere adding student or not
bool View::selection(){
  int numOptions = 1;
  int selection = -1;
  cout << endl;
  cout << "(1) Add Student" << endl;
  cout << "(0) Exit" << endl;
  while(selection < 0 || selection > numOptions){
    cout << "Enter your selection: ";
    cin >> selection;
  }
  bool n = (selection==1)? true : false;    // input 1 to adding student
  return n;
}

// read id
void View::readStuId(int& stuId){
  cout << "student id:   ";
  cin  >> stuId;
}

// read student course information, passing the value to refrence
void View::readStuCourse(int& courseCode,int& grade,int& term, string& prof){
  cout << "course code <0 to end>:  ";
  cin >> courseCode;
  if(courseCode == 0) return;
  cout << "grade:                   ";
  cin  >> grade;
  cout << "term:           ";
  cin >> term;
  cout << "Course instructor:             ";
  cin >> prof;
}

// print storage
void View::printStorage(Storage& storage){
  storage.print();
}
