#ifndef GPAMONITOR_H
#define GPAMONITOR_H

#include "Monitor.h"

class GPAMonitor :public Monitor
{
  public:
    GPAMonitor(float);
    virtual void update(Student*); // update call gpa Monitor
    void printLogs();              // print information 
  private:
    float threshold_gpa;  //minimum threshold
  };

  #endif
