#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Storage.h"
// collection class keep the student
Storage::Storage():numStudent(0){}
// desctrct the student
Storage::~Storage(){
  for(int i = 0; i < numStudent; i++)
    delete student[i];
}
// adding student to the storage
Storage& Storage::operator+=(Student* s){
  student[numStudent] = s;
  numStudent++;
  return *this;
}
// print the all information for students
void Storage::print(){
  cout << "\n--------The list of student in storage------"<<endl;
  for(int i = 0; i < numStudent; i++){
    cout << i+1 << ". ";
    student[i]->print();
  }
}
