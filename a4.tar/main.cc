#include <iostream>
using namespace std;
#include <string>

#include "defs.h"
//#include "Student.h"
//#include "Storage.h"
//#include "Course.h"
#include "Control.h"

int  mainMenu();

int main()
{
    Control control;  //create control object
    control.launch(); // lauch the program
}
