#ifndef COURSELIST_H
#define COURSELIST_H
#include "Course.h"
#include "List.h"

class CourseList: public List<Course>
{
  public:
    CourseList();             //constucter
    float computeGPA();  //function that returns the average of all course grades
    int computeNumFW(); // courses that the student has failed or withdraw
    void print();
  private:
};

#endif
