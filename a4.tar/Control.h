#ifndef CONTROL_H
#define CONTROL_H

#include <string>
#include "Storage.h"
#include "View.h"
#include "Monitor.h"
#include "StuServer.h"
#include <vector>

using namespace std;

class Control{
public:
  Control();
  ~Control();
  void notify(Student* newStu);  // notify the monitor objects when a new student is created
  void launch();                 // run program

private:
  Storage storage;          //  store student
  vector<Monitor*> monitor;  //  keep the monitor object
  View    view;             //  read the input
  StuServer stuServer;      // student servers


};
#endif
