Peng Li 101047123
Date: 2019 Mar 23th

purpose:
    Update the assignment 2, add abstract class and inheritance to implement encapsulation.
    two extra class one of it keep fail/withdraw and one of it keep gpa(lower value)
    and make sure there is no memory leak in the memory.
source:
Course.cc	Makefile	in.txt    Course.h	    Storage.cc	 Student.cc	  in2.txt
Storage.h	Student.h	defs.h	  List.cc		    List.h 		   Control.cc 	Control.h
View.cc	  View.h		main.cc   FWMonitor.cc  FWMonitor.h  GPAMonitor.h
GPAMonitor.cc       Monitor.cc        Monitor.h
compile:
  "tar -xvf Assignment3_PengLi" unzip the file
  "make clean" make sure it is clean
  "make" compile all the class
  "./a3<in.txt" to check for the all output(ignore in2.txt it just a test file)
  "valgrind ./a3<in.txt" to check the memory is leak or not.
