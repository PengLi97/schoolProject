#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "FWMonitor.h"

// constructor
FWMonitor::FWMonitor(int n):threshold_courses(n){}

/* update students have failed or withdrawn
from a number of courses higher than another
preset value
*/
void FWMonitor:: update(Student* stu){
// if meet the request add it into the logss
  if (stu->computeNumFW() > threshold_courses)
    logs.push_back(stu);
}

//print student id and the number of failed/wihtdraw 
void FWMonitor::printLogs(){
  for (int i=0; i<logs.size(); ++i)
    cout << "student ID: "<< logs[i]->getId()
         << "     The number of failed/withdraw: "<<logs[i]->computeNumFW()
         << endl;

}
