#include <iostream>
#include <iomanip>
using namespace std;

#include "Control.h"
#include "GPAMonitor.h"
#include "FWMonitor.h"

Control::Control(){
  Monitor* gpaM = new GPAMonitor(3.0);  // set minimum gpa
  Monitor*  fwM  = new FWMonitor(2);    // set fails > 2
  monitor.push_back(gpaM);              //add GPAMonitor into monitor vector
  monitor.push_back(fwM);               // add FWMonitor into monitor verctor
}
// destrctor for monitor pointer
Control::~Control(){
    for(int i = 0; i < monitor.size() ; i++)
      delete monitor[i];
}
// if there is a new student been added
void Control::notify(Student* newStu){
  for(int i = 0; i < monitor.size() ; i++)
    monitor[i]->update(newStu);

}

void Control::launch()
{
  int courseCode,stuId,grade,term;
  string prof;

  while (view.selection()){
    view.readStuId(stuId); // create dynamic allocater for student
    Student* student = new Student(stuId);
    view.readStuCourse(courseCode,grade,term,prof);
      while(courseCode != 0){
        Course* course = new Course(courseCode,grade,term,prof);// create temp course allocate
        student->addCourse(course); // add course to the student
        view.readStuCourse(courseCode,grade,term,prof);
      }
    notify(student);
    storage.addStu(student); // add student to the storage
  }
  view.printStorage(storage);
    cout << "----------------------------storage end------------------"<< endl;
    cout << "--------Student in GPAMonitor" << endl;
    monitor[0]->printLogs();
    cout << "--------Student in FWMonitor" << endl;
    monitor[1]->printLogs();
}
