#ifndef FWMONITOR_H
#define FWMONITOR_H

#include "Monitor.h"
class FWMonitor :public Monitor
{
  public:
    FWMonitor(int);
    virtual void update(Student*);  // udpata student information we called this subclasss
    void printLogs();               // print information
  private:
    int threshold_courses;  // minimum threshold courses
  };

  #endif
