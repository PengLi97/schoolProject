#ifndef VIEW_H
#define VIEW_H

#include <string>
#include "Student.h"
#include "Storage.h"
using namespace std;

class View{
  public:
    View();                // view the all inputs
    bool selection();      // define either add not not add student or course
    void readStuId(int&);      // read all student id
    void readStuCourse(int&,int&,int&,string&);  // read the course that student take
    void printStorage(Storage&);  // print out the library
  private:

};

#endif
