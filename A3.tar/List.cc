#include <iostream>
using namespace std;

#include "List.h"

// initialize the list
List::List()
{
  head = NULL;
  tail = NULL;
}

List::~List()
{
  Node *currNode, *nextNode; // crrent node and next node

  currNode = head;

  while (currNode != NULL) {
    nextNode = currNode->next;
    delete currNode -> data;
    delete currNode;
    currNode = nextNode;
  }
}
// add course to the list
void List::add(Course* course)
{
  Node* tmpNode;      //keep the adding course
  Node* currNode;     //current position
  Node* prevNode;     // previous node

  tmpNode = new Node;
  tmpNode->data = course;
  tmpNode->next = NULL;

  currNode = head;
  prevNode = NULL;
  // if list is not empty
  while (currNode != NULL) {
    if (course->lessThan(currNode->data)) // if couse less than this, break while
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }
  // if list is empty
  if (prevNode == NULL) {
    head = tmpNode;
    tail = tmpNode;
  }
  else {
    prevNode->next = tmpNode;
  }
  tmpNode->next = currNode;
    if(currNode == NULL)
        tail = tmpNode;
    else{
        while(currNode->next != NULL)
            currNode = currNode -> next;
    tail = currNode;
    }
}

//compute the average of the gpa
float List::computeGPA(){
    float gpa = 0; //keep the gpa
    float n = 0;   //count the total course
    Node* currNode = head; // recode state on each stated
    while(currNode != NULL){
      gpa += currNode->data->getGrade();
      n++;
      currNode = currNode->next;
    }
    return (gpa/n);
}

//count the course fail or withdraw
int List::computeNumFW(){
  int n= 0;  // count the number of course
  Node* currNode = head; // recode state on each stated
  while (currNode != NULL){
    if (currNode->data->getGrade() == -1 || currNode->data->getGrade() == 0)
        n++;
    currNode = currNode->next;
  }
  return n;
}

// print out the course information
void List::print()
{
  Node* currNode = head;
// loop the list
  while (currNode != NULL) {
    currNode->data->print();
    currNode = currNode->next;
  }
// print the head and tail
  cout <<"--------------" << endl;
  // print the avg and fail/withdraw
  cout << "the courses avg: " << computeGPA() << endl;
  cout << "Fail/withdraw(#): " << computeNumFW() << endl;
  cout << "-----------------------" << endl;



}
