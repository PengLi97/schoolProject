#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "GPAMonitor.h"

// constructor
GPAMonitor::GPAMonitor(float avg):threshold_gpa(avg){}

// updata students have a GPA below the preset minimum
void GPAMonitor::update(Student* stu){
  // if meet request add to logs
  if(stu->computeGPA() < threshold_gpa)
    logs.push_back(stu);
}

// print the student id and corresponding gpa
void GPAMonitor::printLogs(){
  for (int i=0; i<logs.size(); ++i)
    cout << "student ID: "<< logs[i]->getId()
         << "    corresponding GPA "<< logs[i]->computeGPA() << endl;
}
