#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Student.h"

// default parameter
Student::Student(int i):id(i){}

Student::~Student(){}

// adding course
void Student::addCourse(Course* c){
  courses.add(c);  //saving the course to the list
}

// compute average
float Student::computeGPA(){
  return courses.computeGPA();
}

// count failed and withdraw
int Student::computeNumFW(){
  return courses.computeNumFW();
}

// get student id
int Student:: getId(){
  return id;
}

// print id
void Student::print(){
  cout<< endl << "Id: " << id << endl;
  courses.print();
}
