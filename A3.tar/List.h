#ifndef LIST_H
#define LIST_H

#include "Course.h"
// the collection class to store courses
class List
{
  class Node
  {
    friend class List;  // node is List friend allowed list use it member
    private:
      Course* data;     // store data
      Node*   next;     // pointer to next one
  };

  public:
    List();             //constucter
    ~List();            //destrctor
    void add(Course*);  //adding course to the list
    void print();       //print the information
    float computeGPA();  //function that returns the average of all course grades
    int computeNumFW(); // courses that the student has failed or withdraw

  private:
    Node* head;
    Node* tail;
};

#endif
