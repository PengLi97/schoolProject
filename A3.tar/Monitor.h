#ifndef MONITOR_H
#define MONITOR_H
#include <vector>

#include "Student.h"

class Monitor
{
  public:
    Monitor();
    virtual ~Monitor();
    virtual void update(Student*) = 0; // prue virtual function
    virtual void printLogs();         // print the detail
  protected:
    vector<Student*> logs;       //stores a collection of logs
  };

  #endif
