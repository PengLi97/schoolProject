package com.comp1601.tictactoe;

public class Coordinate {
    private int row;   // 0 is the bottom horizontal row
    private int column;   // 0 is the left vertical column
    private final static int MAXROW = 2;
    private final static int MAXCOLUMN = 2;

    public Coordinate(int column, int row) throws IndexOutOfBoundsException {
        if ((column < 0) || (column > MAXCOLUMN))
            throw new IndexOutOfBoundsException("column must be between 0 and 2,inclusive");
        if ((row < 0) || (row > MAXROW))
            throw new IndexOutOfBoundsException("row must be between 0 and 2,inclusive");
        this.row = row;
        this.column = column;
    }

    public int getColumn() {
        return this.column;
    }

    public int getRow() {
        return this.row;
    }


    @Override
    public String toString() {
        return "(" + getColumn() + "," + getRow() + ")";
    }
}