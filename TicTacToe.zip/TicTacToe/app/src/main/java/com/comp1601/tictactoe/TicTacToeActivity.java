package com.comp1601.tictactoe;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.util.Log;
import android.widget.TextView;

public class TicTacToeActivity extends AppCompatActivity {

    private Button button_00;
    private Button button_01;
    private Button button_02;
    private Button button_10;
    private Button button_11;
    private Button button_12;
    private Button button_20;
    private Button button_21;
    private Button button_22;
    private Button restart;
    private TextView winner;
    private TextView X_winTime;
    private TextView O_winTime;
    private int countX = 0;
    private int countO = 0;
    private boolean xTurn = true; // adjust either 'X' or 'O' turn
    private boolean gameEnd = false; // adjust winner appear or not
    private TicTacToeGame board; // the board for the game
    private static String keep_X = "keep_X"; // save the data for "X" win times
    private static String keep_O = "keep_O"; // save the data for "O" win times
    private  final String TAG = this.getClass().getSimpleName() + " @" + System.identityHashCode(this);

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(keep_X,countX);
        savedInstanceState.putInt(keep_O,countO);
        Log.i(TAG, "onSaveInstanceState(Bundle)");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);

        button_00 = (Button) findViewById(R.id.button_00);
        button_01 = (Button) findViewById(R.id.button_01);
        button_02 = (Button) findViewById(R.id.button_02);
        button_10 = (Button) findViewById(R.id.button_10);
        button_11 = (Button) findViewById(R.id.button_11);
        button_12 = (Button) findViewById(R.id.button_12);
        button_20 = (Button) findViewById(R.id.button_20);
        button_21 = (Button) findViewById(R.id.button_21);
        button_22 = (Button) findViewById(R.id.button_22);
        restart   = (Button) findViewById(R.id.button_restart);
        restart.setEnabled(false);

        winner    = (TextView) findViewById(R.id.END);
        X_winTime = (TextView) findViewById(R.id.countX);
        O_winTime = (TextView) findViewById(R.id.countO);
        board = new TicTacToeGame();  //the game board
        // update the previous data
        if(savedInstanceState != null){
            countX = savedInstanceState.getInt(keep_X, 0);
            countO = savedInstanceState.getInt(keep_O, 0);
            X_winTime.setText(""+countO);
            O_winTime.setText(""+countX);
        }

        button_00.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(0,0) Pressed");
                if(gameEnd) return; // if game end button would not have any action
                if(button_00.getText().toString() != "") return; // if button been clicked before would have action
                button_00.setBackgroundColor(Color.YELLOW); //change button background color
                // adjust this step either "X" or "O"
                if(xTurn) {
                    button_00.setText("X");
                    xTurn = false;
                }
                else{
                    button_00.setText("O");
                    xTurn = true;
                }
                // add X/O to our game board
                board.addPeice(new Square(new Coordinate(0,0),button_00.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });
        button_01.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(0,1) Pressed");
                if(gameEnd) return;
                if(button_01.getText().toString() != "")
                    return;

                button_01.setBackgroundColor(Color.YELLOW);
                if(xTurn) {
                    button_01.setText("X");
                    xTurn = false;
                }
                else{
                    button_01.setText("O");
                    xTurn = true;
                }

                board.addPeice(new Square(new Coordinate(0,1),button_01.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });
        button_02.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(0,2) Pressed");
                if(gameEnd) return;
                if(button_02.getText().toString() != "")
                    return;

                button_02.setBackgroundColor(Color.YELLOW);
                if(xTurn) {
                    button_02.setText("X");
                    xTurn = false;
                }
                else{
                    button_02.setText("O");
                    xTurn = true;
                }

                board.addPeice(new Square(new Coordinate(0,2),button_02.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });
        button_10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(1,0) Pressed");
                if(gameEnd) return;
                if(button_10.getText().toString() != "")
                    return;

                button_10.setBackgroundColor(Color.YELLOW);
                if(xTurn) {
                    button_10.setText("X");
                    xTurn = false;
                }
                else{
                    button_10.setText("O");
                    xTurn = true;
                }

                board.addPeice(new Square(new Coordinate(1,0),button_10.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });
        button_11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(1,1) Pressed");
                if(gameEnd) return;
                if(button_11.getText().toString() != "")
                    return;

                button_11.setBackgroundColor(Color.YELLOW);
                if(xTurn) {
                    button_11.setText("X");
                    xTurn = false;
                }
                else{
                    button_11.setText("O");
                    xTurn = true;
                }

                board.addPeice(new Square(new Coordinate(1,1),button_11.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });
        button_12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(1,2) Pressed");
                if(gameEnd) return;
                if(button_12.getText().toString() != "")
                    return;

                button_12.setBackgroundColor(Color.YELLOW);
                if(xTurn) {
                    button_12.setText("X");
                    xTurn = false;
                }
                else{
                    button_12.setText("O");
                    xTurn = true;
                }

                board.addPeice(new Square(new Coordinate(1,2),button_12.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });
        button_20.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(2,0) Pressed");
                if(gameEnd) return;
                if(button_20.getText().toString() != "")
                    return;

                button_20.setBackgroundColor(Color.YELLOW);
                if(xTurn) {
                    button_20.setText("X");
                    xTurn = false;
                }
                else{
                    button_20.setText("O");
                    xTurn = true;
                }

                board.addPeice(new Square(new Coordinate(2,0),button_20.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });
        button_21.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(2,1) Pressed");
                if(gameEnd) return;
                if(button_21.getText().toString() != "")
                    return;

                button_21.setBackgroundColor(Color.YELLOW);
                if(xTurn) {
                    button_21.setText("X");
                    xTurn = false;
                }
                else{
                    button_21.setText("O");
                    xTurn = true;
                }

                board.addPeice(new Square(new Coordinate(2,1),button_21.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });
        button_22.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i(TAG, "button(2,2) Pressed");
                if(gameEnd) return;
                if(button_22.getText().toString() != "")
                    return;

                button_22.setBackgroundColor(Color.YELLOW);
                if(xTurn) {
                    button_22.setText("X");
                    xTurn = false;
                }
                else{
                    button_22.setText("O");
                    xTurn = true;
                }

                board.addPeice(new Square(new Coordinate(2,2),button_22.getText().charAt(0)));
                Log.i(TAG,board.toString());//print the board in logcat
                checkForWinner();
            }
        });

        //if re-try button click, all the button and board would clean and initialize
        restart.setOnClickListener(v-> {
            Log.i(TAG, "restart button Pressed");
            board = new TicTacToeGame();
            gameEnd = false;
            xTurn = true;
            restart.setEnabled(false);
            restart.setVisibility(View.INVISIBLE);
            winner.setVisibility(View.INVISIBLE);
            button_00.setText("");
            button_01.setText("");
            button_02.setText("");
            button_10.setText("");
            button_11.setText("");
            button_12.setText("");
            button_20.setText("");
            button_21.setText("");
            button_22.setText("");
            button_00.setBackgroundResource(android.R.drawable.btn_default);
            button_01.setBackgroundResource(android.R.drawable.btn_default);
            button_02.setBackgroundResource(android.R.drawable.btn_default);
            button_10.setBackgroundResource(android.R.drawable.btn_default);
            button_11.setBackgroundResource(android.R.drawable.btn_default);
            button_12.setBackgroundResource(android.R.drawable.btn_default);
            button_20.setBackgroundResource(android.R.drawable.btn_default);
            button_21.setBackgroundResource(android.R.drawable.btn_default);
            button_22.setBackgroundResource(android.R.drawable.btn_default);
        });

    }
    //check for winner in 3 situation(X win or O win or no winner)
    public void checkForWinner(){
        if(board.OwinTheGame()){
            gameEnd = true;
            winner.setVisibility(View.VISIBLE);
            winner.setText("O WIN");
            restart.setVisibility(View.VISIBLE);
            restart.setEnabled(true);
            countO++;
            O_winTime.setText(""+countO);
            Log.i(TAG,"O win");
            return;

        }
        if(board.XwinTheGame()){
            gameEnd = true;
            winner.setVisibility(View.VISIBLE);
            winner.setText("X WIN");
            restart.setVisibility(View.VISIBLE);
            restart.setEnabled(true);
            countX++;
            X_winTime.setText(""+countX);
            Log.i(TAG,"X win");
            return;

        }
        if(board.fullSet()){
            gameEnd = true;
            winner.setVisibility(View.VISIBLE);
            winner.setText("NOBODY WIN");
            restart.setVisibility(View.VISIBLE);
            restart.setEnabled(true);
            Log.i(TAG,"NO ONE WIN");
            return;
        }
    }


}
