package com.comp1601.tictactoe;

public class TicTacToeGame {

    private Square board[][];
    private final static int MAXROW = 3;
    private final static int MAXCOLUMN = 3;

    public TicTacToeGame() {
        /* set 3*3 game board
           initialize the board
        */
        board = new Square[MAXCOLUMN][MAXROW];
        for (int c = 0; c < MAXCOLUMN; c++) {
            for (int r = 0; r < MAXROW; r++) {
                board[c][r] = new Square(new Coordinate(c, r));
            }
        }
        reset(); // make sure nothing in the board
    }

    public void reset() {
        // clean the piece that set in board
        for (int c = 0; c < MAXCOLUMN; c++)
            for (int r = 0; r < MAXROW; r++)
                board[c][r].reset();
    }

    public void addPeice(Square p){
        board[p.getColumn()][p.getRow()] = p;
    }

    //print the board to check what in the board this time
    public String toString(){
        String s = "Board\n";
        for (int c = 0; c < MAXCOLUMN; c++) {
            for (int r = 0; r < MAXROW; r++) {
                char p = board[c][r].getPiece();
                s += (p == 0) ? " " : p;
                if(r != 2)
                    s += "|";
            }
            s += "\n";
        }
        return s;
    }

    //check whether board have been full set or not.
    public boolean fullSet(){
        for (int c = 0; c < MAXCOLUMN; c++) {
            for (int r = 0; r < MAXROW; r++) {
                char p = board[c][r].getPiece();
                if (p == 0) return false;
            }
        }
        return true;

    }

    public boolean XwinTheGame() {
        // check for win in column
        for (int i = 0; i < MAXCOLUMN; i++) {
            if (board[i][0].getPiece() == 'X' && board[i][1].getPiece() == 'X' &&
                    board[i][2].getPiece() == 'X')
                return true;
        }
        // check for win in row
        for (int i = 0; i < MAXROW; i++) {
            if (board[0][i].getPiece() == 'X' && board[1][i].getPiece() == 'X' &&
                board[2][i].getPiece() == 'X')
                return true;
        }

        //check for win in cross
        for (int i = 0; i < MAXCOLUMN; i++) {
            if (board[i][i].getPiece() != 'X')
                break;
            if(i == MAXCOLUMN-1)
                return true;
        }
        if(board[0][2].getPiece() == 'X' && board[1][1].getPiece() == 'X' &&
           board[2][0].getPiece() == 'X')
            return true;

        return false;
    }

    public boolean OwinTheGame() {

        for (int i = 0; i < MAXROW; i++) {
            if (board[i][0].getPiece() == 'O' && board[i][1].getPiece() == 'O' &&
                    board[i][2].getPiece() == 'O')
                return true;
        }
        for (int i = 0; i < MAXCOLUMN; i++) {
            if (board[0][i].getPiece() == 'O' && board[1][i].getPiece() == 'O' &&
                    board[2][i].getPiece() == 'O')
                return true;
        }
        for (int i = 0; i < MAXCOLUMN; i++) {
            if (board[i][i].getPiece() != 'O')
                break;
            if (i == MAXCOLUMN - 1)
                return true;
        }
        if (board[0][2].getPiece() == 'O' && board[1][1].getPiece() == 'O' &&
                board[2][0].getPiece() == 'O')
            return true;

        return false;
    }
}
