package com.comp1601.tictactoe;

public class Square {
    private Coordinate coordinate;
    private char piece;

    public Square(Coordinate c) {
        this.coordinate = c;     //
        this.piece = 0;      // No piece is positioned on this square
    }
    public Square(Coordinate c, char p) {
        this( c );
        this.piece = p;      // A piece is positioned on this square
    }
    public void reset(){ this.piece = 0; } // clean the piece
    public char getPiece() {return this.piece; }
    public int getColumn() { return coordinate.getColumn(); }
    public int getRow() { return coordinate.getRow(); }
    public String toString(){
        //print the coordinate and piece
        return "Coordinate (" + getColumn() + " , " + getRow()
                + ")" + "Piece (" + getPiece()+")";
    }

}
