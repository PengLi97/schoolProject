package com.comp1601.tictactoe;

import org.junit.Test;
import static org.junit.Assert.*;

public class TicTacToeGameUnitTest {

    @Test
    public void test_X_Row_Win(){
        TicTacToeGame board = new TicTacToeGame();
        Square c0r0 = new Square(new Coordinate(0,0),'X');
        Square c1r0 = new Square(new Coordinate(1,0),'X');
        Square c2r0 = new Square(new Coordinate(2,0),'X');
        board.addPeice(c0r0);
        board.addPeice(c1r0);
        board.addPeice(c2r0);
        boolean result = board.XwinTheGame();
        assertEquals(true,result);
    }
    @Test
    public void test_X_Row(){
        TicTacToeGame board = new TicTacToeGame();
        Square c0r1 = new Square(new Coordinate(0,1),'X');
        Square c1r1 = new Square(new Coordinate(1,1),'O');
        Square c2r1 = new Square(new Coordinate(2,1),'X');
        board.addPeice(c0r1);
        board.addPeice(c1r1);
        board.addPeice(c2r1);
        boolean result = board.XwinTheGame();
        assertEquals(false,result);
    }
    @Test
    public void test_X_Column_Win(){
        TicTacToeGame board = new TicTacToeGame();
        Square c2r0 = new Square(new Coordinate(2,0),'X');
        Square c2r1 = new Square(new Coordinate(2,1),'X');
        Square c2r2 = new Square(new Coordinate(2,2),'X');
        board.addPeice(c2r0);
        board.addPeice(c2r1);
        board.addPeice(c2r2);
        boolean result = board.XwinTheGame();
        assertEquals(true,result);
    }
    @Test
    public void test_X_Column(){
        TicTacToeGame board = new TicTacToeGame();
        Square c2r0 = new Square(new Coordinate(2,0),'X');
        Square c2r1 = new Square(new Coordinate(2,1),'O');
        Square c2r2 = new Square(new Coordinate(2,2),'X');
        board.addPeice(c2r0);
        board.addPeice(c2r1);
        board.addPeice(c2r2);
        boolean result = board.XwinTheGame();
        assertEquals(false,result);
    }
    @Test
    public void test_X_Cross_left(){
        TicTacToeGame board = new TicTacToeGame();
        Square c0r0 = new Square(new Coordinate(0,0),'X');
        Square c1r1 = new Square(new Coordinate(1,1),'O');
        Square c2r2 = new Square(new Coordinate(2,2),'X');
        board.addPeice(c0r0);
        board.addPeice(c1r1);
        board.addPeice(c2r2);
        boolean result = board.XwinTheGame();
        assertEquals(false,result);
    }
    @Test
    public void test_X_Cross_right(){
        TicTacToeGame board = new TicTacToeGame();
        Square c0r2 = new Square(new Coordinate(0,2),'X');
        Square c1r1 = new Square(new Coordinate(1,1),'X');
        Square c2r0 = new Square(new Coordinate(2,0),'X');
        board.addPeice(c0r2);
        board.addPeice(c1r1);
        board.addPeice(c2r0);
        boolean result = board.XwinTheGame();
        assertEquals(true,result);
    }




}
