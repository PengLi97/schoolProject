#ifndef CONTROL_H
#define CONTROL_H

#include <string>
#include "Storage.h"
#include "View.h"
using namespace std;

class Control{
public:
  Control();
  void launch();    // run program

private:
  Storage storage;  //  store student
  View    view;     // read the input


};
#endif
