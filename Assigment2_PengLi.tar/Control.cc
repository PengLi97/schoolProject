#include <iostream>
#include <iomanip>
using namespace std;

#include "Control.h"

Control::Control(){}

void Control::launch()
{
  int courseCode = 1; // adjust course code either 0 or not
  while (view.selection()){
    Student* student = view.readStuId(); // create dynamic allocater for student
    Course* course =  view.readStuCourse(); // create temp course allocarter
      while(course != NULL){                // check is course exist or not
        student->addCourse(course); // add course to the student
        course = view.readStuCourse();
      }
    storage.addStu(student); // add student to the storage
  }
  view.printStorage(storage);
}
