#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Student.h"

// default parameter
Student::Student(int i):id(i){}

Student::~Student(){}

void Student::addCourse(Course* c){
  courses.add(c);  //saving the course to the list
}

void Student::print()
{
  cout<< endl << "Id: " << id << endl;
  courses.print();
}
