#ifndef STUDENT_H
#define STUDENT_H

#include "defs.h"
#include "Course.h"
#include "List.h"

class Student
{
  public:
    Student(int=0);
    ~Student(); //destrctor construction
    void addCourse(Course*);  //adding couse to the array
    void print();

  private:
    int    id;
    List courses; // list keep the courses
};

#endif
