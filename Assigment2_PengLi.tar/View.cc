#include <iostream>
#include <iomanip>
using namespace std;
#include "View.h"
View:: View(){
}
// decide wethere adding student or not
bool View::selection(){
  int numOptions = 1;
  int selection = -1;
  cout << endl;
  cout << "(1) Add Student" << endl;
  cout << "(0) Exit" << endl;
  while(selection < 0 || selection > numOptions){
    cout << "Enter your selection: ";
    cin >> selection;
  }
  bool n = (selection==1)? true : false;    // input 1 to adding student
  return n;
}

Student* View::readStuId(){
  int stuId; // student id
  string prof;
  cout << "student id:   ";
  cin  >> stuId;
  Student* student = new Student(stuId);
  return student;
}

Course* View::readStuCourse(){
  int courseCode, grade, term;//course code, grade, term
  string prof;                //Course instructor
  cout << "course code <0 to end>:  ";
  cin >> courseCode;
  if(courseCode == 0) // if course code is 0 means no course
      return NULL;
  cout << "grade:                   ";
  cin  >> grade;
  cout << "term:           ";
  cin >> term;
  cout << "Course instructor:             ";
  cin >> prof;
    //saving it, since it pointer we have to new it and add to student
  Course* course = new Course(courseCode,grade,term,prof);
  return course;
}

void View::printStorage(Storage& storage){
  storage.print();
}
