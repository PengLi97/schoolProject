#ifndef LIST_H
#define LIST_H

#include "Course.h"
// the collection class to store courses
class List
{
  class Node
  {
    friend class List;  // node is List friend allowed list use it member
    private:
      Course* data;     // store data
      Node*   next;     // pointer to next one
  };

  public:
    List();             //constucter
    ~List();            //destrctor
    void add(Course*);  //adding course to the list
    void print();       //print the information

  private:
    Node* head;
    Node* tail;
};

#endif
