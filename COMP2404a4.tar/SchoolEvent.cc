#include <iostream>
#include <iomanip>
using namespace std;

#include "SchoolEvent.h"

SchoolEvent::SchoolEvent(string n, int prio) : Event(n,prio){}
// Event child class,include it's own compare method
bool SchoolEvent::operator<(Event* e){
    if(this->getDate() < e->getDate())  return true;
    else return false;
}
