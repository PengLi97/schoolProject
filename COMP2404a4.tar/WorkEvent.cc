#include <iostream>
#include <iomanip>                                                              
using namespace std;                                                            
                                                                                
#include "WorkEvent.h"                                                        
                                                                                
WorkEvent::WorkEvent(string n, int prio) : Event(n,prio){}                  
                                                                                
bool WorkEvent::operator<(Event* e){
        if(this->getPriority() < e->getPriority())  return true;
        else return false;
} 
