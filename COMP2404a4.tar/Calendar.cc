#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//A Calendar object contain multiple Events

#include "Calendar.h"
#include "List.h"

Calendar::Calendar(string n)
{
    name = n;
}

Calendar::~Calendar()
{
   
}

void Calendar::add(Event* e)
{
    list.add(e);
}

void Calendar::format(string& outStr)const
{
    list.format(outStr);
}
void Calendar::copyEvents(Array& a){
    list.copy(a);
}
