#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "SchoolEvent.h"
#include "WorkEvent.h"
#include "Control.h"
#include "Calendar.h"
#include "Date.h"
#include "Event.h"
#include "View.h"

Control::Control()
{
    Array schoolArr, workArr;
    eventServer.retrieve(schoolArr,workArr);
    for (int i=0; i<schoolArr.getSize(); i++){
        school.add(schoolArr.get(i));
    }
    for (int i=0; i<workArr.getSize(); i++){
        work.add(workArr.get(i));
    }

}

Control::~Control()
{
    Array schoolArr, workArr;
    school.copyEvents(schoolArr);
    work.copyEvents(workArr);
    eventServer.update(schoolArr,workArr);
}

void Control::launch()
{
    bool Flag = true;
    int day,month,year,hour,minute,prio;
    string Eventname;
    string schoolStr;// keep the sting in school
    string workStr;//keep the string in work
    while (Flag == true){
        Flag = view.Display();
        if (Flag == true){
            view.Reading(day,month,year,Eventname,hour,minute,prio);
            //adjust the type of the event
            if(view.readEventType()==true){
                Event* newEvent = new SchoolEvent(Eventname,prio);
                newEvent->setDate(day,month,year,hour,minute);
                school.add(newEvent);
            }
            else{   
                Event* newEvent = new WorkEvent(Eventname,prio);
                newEvent->setDate(day,month,year,hour,minute);
                work.add(newEvent);
             }
        }
    }
    cout <<"\n----------School event------------\n";
    school.format(schoolStr);
    view.PrintCalendar(schoolStr);
    cout <<"----------Work event------------\n";
    work.format(workStr);
    view.PrintCalendar(workStr);

}
