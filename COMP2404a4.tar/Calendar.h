#ifndef CALENDAR_H
#define CALENDAR_H

#include "Event.h"
#include "List.h"

#define size 128

class Calendar
{
    public:
      Calendar(string="");
      ~Calendar();
      void add(Event*);
      void format(string&)const;
      void copyEvents(Array&);
    private:
      string name;
      List<Event> list;

};








#endif
