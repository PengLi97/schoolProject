#include <string>
#include "View.h"
#include "Calendar.h"
#include "EventServer.h"
using namespace std;

class Control
{
    public:
        Control();
        ~Control();
        void launch();
    private:
        Calendar school; // contain school calendar
        Calendar work;  // contain work calender
        View view;
        EventServer eventServer; //server
};

