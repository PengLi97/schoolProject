#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;

//An Event object include name and date of itself

#include "Event.h"
#include "Date.h"

Event::Event(string n,int prio)
{
    name = n;
    priority = prio;
}
Event::~Event(){}

void Event::format(string& outStr)const
{
    stringstream strTime;
    strTime<<name<<"\n"<<priority<<endl;
    outStr += strTime.str();
    date.format(outStr);
}

Date* Event::getDate()
{
    Date* a = &date;
    return a;
}
int Event::getPriority() { return priority;}

void Event::setDate(int d, int m, int y, int h, int min)
{
    date.set(d,m,y,h,min);
}
