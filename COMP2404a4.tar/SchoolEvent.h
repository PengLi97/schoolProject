#ifndef SCHOOLEVENT_H
#define SCHOOLEVENT_H

#include "Event.h"
#include <string>
using namespace std;
// Event child class, include it's own compare method
class SchoolEvent : public Event
{
    public:
        SchoolEvent(string, int);
        //bool lessThan(Event*);
        bool operator<(Event*);
};

#endif
