#ifndef VIEW_H
#define VIEW_H
#include <string>
using namespace std;

#include "Calendar.h"

#define MAX_ARR_SIZE  128

class View
{
    public:
     bool Display();
     void Reading(int&,int&,int&,string&,int&,int&,int&);
     bool readEventType();
     void PrintCalendar(string&);
     
};

#endif
