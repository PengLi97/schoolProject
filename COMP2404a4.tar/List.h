#ifndef LIST_H
#define LIST_H
#include <string>
#include "Event.h"
#include "Array.h"

using namespace std;

template <class T>
class List
{
    template<class V>
    class Node
    {
        friend class List;
        private:
        V* event;
        Node<V>* next;
        Node<V>* prev;
    };
 
    public:
        List();
        ~List();
        void add(T*); 
        void format(string& outStr)const;
        void copy(Array&); 

    private:
        Node<T>* head;
};

template <class T>
List<T>::List(){
    head = NULL;
}
template <class T>
List<T>::~List(){
  Node<T> *currNode, *nextNode;

  currNode = head;

  while (currNode != NULL) {
    nextNode = currNode->next;
    delete currNode->event;
    delete currNode;
    currNode = nextNode;
  }

}

//add Event* into List
template <class T>
void List<T>::add(T* event){
  Node<T>* tmpNode;
  Node<T>* currNode;
  Node<T>* prevNode;

  tmpNode = new Node<T>;
  tmpNode->event = event;
  tmpNode->next = NULL;

  currNode = head;
  prevNode = NULL;

  while (currNode != NULL) {
    if (event< currNode->event)
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }

  if (prevNode == NULL) {
    head = tmpNode;
  }
  else {
    prevNode->next = tmpNode;
  }

  if (currNode != NULL){
    currNode->prev = tmpNode;
    tmpNode->prev = prevNode;
  }

  tmpNode->next = currNode;
}

template <class T>
void List<T>::format(string& outStr)const{
    Node<T>* currNode = head;
    
    while (currNode != NULL) {
        currNode->event->format(outStr);
        currNode = currNode->next;
    }
}

template <class T>
void List<T>::copy(Array& a){
    Node<T>* currNode = head;

    while(currNode != NULL){
        a.add(currNode->event);
        currNode = currNode->next;
    }
}


#endif
